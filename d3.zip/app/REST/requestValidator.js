import Joi from 'joi';

/*export default {
  authenticate: {
    payload: {
      login: Joi.string().required(),
      password: Joi.string().required()
    }
  },*/
/*
export const authenticatePayloadSchema =Joi.object({
  login: Joi.string().required(),
  password: Joi.string().required()
});

export default {
  authenticatePayload: {
    payload: authenticatePayloadSchema

  },

  createOrUpdateUser: {
    payload: {
      id: Joi.string(),
      email: Joi.string(),
      password: Joi.string(),
      name: Joi.string(),
      surname: Joi.string(),
      address: Joi.string(),
      postCode: Joi.string(),
      city: Joi.string(),
      phone: Joi.string(),
      isAdmin: Joi.boolean(),
      avatar: Joi.string(),
      role: Joi.string(),
      active: Joi.boolean(),
      policy: Joi.boolean()
    }
  },
  removeById: {
    params: {
      id: Joi.string().required()
    }
  },
  delete: {
    params: {
      id: Joi.string().required()
    }
  },
  getById: {
    params: {
      id: Joi.string().required()
    }
  },
  getByName: {
    params: {
      name: Joi.string().required()
    }
  },
  activation: {
    params: {
      hash: Joi.string().required()
    }
  },

  removeApplication: {
    params: {
      id: Joi.string().required()
    }
  },
  removeAttachment: {
    params: {
      id: Joi.string().required()
    }
  },
  removeDetails: {
    params: {
      id: Joi.string().required()
    }
  },
  removeStudent: {
    params: {
      id: Joi.string().required()
    }
  },
  createOrUpdateDetails: {
    params: {
      id: Joi.string().required()
    },
    payload: {
      specialization: Joi.string().required(),
      education_level: Joi.string().required(),
      study_system: Joi.string().required(),
      bank_account_number: Joi.string().creditCard().required(),
      current_study_year: Joi.number().integer().min(1).required(),
      other_details: Joi.string().allow('')
    }
  },
  createOrUpdateApplication: {
    params: {
      id: Joi.string().required()
    },
    payload: {
      album_id: Joi.string().required(),
      type: Joi.string().required(),
      details_id: Joi.string().required(),
      status: Joi.string().required(),
      attachment_id: Joi.string().required()
    }
  },
  createAttachment: {
    params: {
      id: Joi.string().required()
    },
    payload:{
      file_name: Joi.string().required(),
      file_data: Joi.string().base64().required()
    }
  },
  createOrUpdateStudent: {
    payload:{
      user_id: Joi.string().required(),
      pesel: Joi.string().regex(/^[0-9]{11}$/).length(11).required(),
      email_address: Joi.string().email().required(),
      phone_number: Joi.string().regex(/^[0-9]{9}$/).length(9),
      address: Joi.string().required()
    }
  }

};*/

// Authentication payload schema
const authenticatePayloadSchema = Joi.object({
  login: Joi.string().required(),
  password: Joi.string().required()
});

// Create or update user payload schema
const createOrUpdateUserSchema = Joi.object({
  id: Joi.string().optional(),
  email: Joi.string().email().optional(),
  password: Joi.string().optional(),
  name: Joi.string().optional(),
  surname: Joi.string().optional(),
  address: Joi.string().optional(),
  postCode: Joi.string().optional(),
  city: Joi.string().optional(),
  phone: Joi.string().optional(),
  isAdmin: Joi.boolean().optional(),
  avatar: Joi.string().optional(),
  role: Joi.string().optional(),
  active: Joi.boolean().optional(),
  policy: Joi.boolean().required()
});

// Remove by ID params schema
const removeByIdSchema = Joi.object({
  id: Joi.string().required()
});

// Activation params schema
const activationSchema = Joi.object({
  hash: Joi.string().required()
});

// Create or update details payload schema
const createOrUpdateDetailsSchema = Joi.object({
  specialization: Joi.string().required(),
  education_level: Joi.string().required(),
  study_system: Joi.string().required(),
  bank_account_number: Joi.string().creditCard().required(),
  current_study_year: Joi.number().integer().min(1).required(),
  other_details: Joi.string().allow('').optional()
});

// Create or update student payload schema
const createOrUpdateStudentSchema = Joi.object({
  applicationId: Joi.string().required(),
  name: Joi.string().required(),
  surname: Joi.string().required(),
  pesel: Joi.string().regex(/^[0-9]{11}$/).length(11).required(),
  email: Joi.string().email().required(),
  phone_number: Joi.string().regex(/^[0-9]{9}$/).length(9).optional(),
  address: Joi.string().required(),
  album_id: Joi.string().required()
});

const getByIdSchema= Joi.object( {
    id: Joi.string().required()
});

const removeStudentSchema = Joi.object({
    id: Joi.string().required()
});

const createOrUpdateApplicationSchema= Joi.object( {
  params: {
    id: Joi.string().required()
  },
  payload: {
    album_id: Joi.string().required(),
    type: Joi.string().required(),
    details_id: Joi.string().required(),
    status: Joi.string().required(),
    attachment_id: Joi.string().required()
  }
});

// Export all validators
const validators = {
  authenticatePayload: {
    payload: authenticatePayloadSchema
  },
  createOrUpdateUser: {
    payload: createOrUpdateUserSchema
  },
  removeById: {
    params: removeByIdSchema
  },
  activation: {
    params: activationSchema
  },
  createOrUpdateDetails: {
    payload: createOrUpdateDetailsSchema
  },
  createOrUpdateStudent: {
    payload: createOrUpdateStudentSchema
  },
  getById:{
    params: getByIdSchema
  },
  removeStudent: {
    params: removeStudentSchema
  }
  // Add other validators as needed for your application
};

export default validators;
