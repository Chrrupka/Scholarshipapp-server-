require('@babel/register');
require('./seed');
