require('@babel/register');
require('./app/index');
